"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { VEKY, listPrvkyByVek } from "@/lib/filters";
import type { VekStupen } from "@/lib/types";

export default function FilterBar() {
  const router = useRouter();
  const search = useSearchParams();

  const [vek, setVek] = useState<VekStupen>(
    (search.get("vek") as VekStupen) ?? "nabor"
  );
  const [prvek, setPrvek] = useState<string>(search.get("prvek") ?? "");

  const prvekOptions = useMemo(() => listPrvkyByVek(vek), [vek]);

  useEffect(() => {
    if (!prvekOptions.includes(prvek)) {
      setPrvek(prvekOptions[0] ?? "");
    }
  }, [vek, prvekOptions, prvek]);

  const goSearch = () => {
    const url = `/search?vek=${encodeURIComponent(vek)}&prvek=${encodeURIComponent(prvek)}`;
    router.push(url);
  };

  return (
    <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-end">
      <div className="flex flex-col">
        <label className="text-xs text-gray-600 mb-1">Věk (ročník)</label>
        <select
          className="rounded-lg border p-2"
          value={vek}
          onChange={(e) => setVek(e.target.value as VekStupen)}
        >
          {VEKY.map((v) => (
            <option key={v.value} value={v.value}>
              {v.label}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col">
        <label className="text-xs text-gray-600 mb-1">Hra</label>
        <select
          className="rounded-lg border p-2"
          value={prvek}
          onChange={(e) => setPrvek(e.target.value)}
        >
          {prvekOptions.length === 0 ? (
            <option value="">— pro tento ročník nejsou dostupné hry —</option>
          ) : (
            prvekOptions.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))
          )}
        </select>
      </div>

      <button
        className="rounded-lg p-2 bg-black text-white md:self-end disabled:opacity-50"
        onClick={goSearch}
        disabled={!prvek}
      >
        Vyhledat
      </button>
    </div>
  );
}
