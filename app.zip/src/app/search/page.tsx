import PrvekCard from "@/components/ui/PrvekCard";
import FilterBar from "@/components/ui/FilterBar";
import { findByPrvekAndVek } from "@/lib/filters";
import type { VekStupen } from "@/lib/types";

type SP = { vek?: VekStupen; prvek?: string };

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<SP>;
}) {
  const { vek = "nabor", prvek = "" } = await searchParams;

  const item = prvek ? findByPrvekAndVek(prvek, vek) : null;

  return (
    <main className="max-w-5xl mx-auto p-6 space-y-6">
      <FilterBar />

      <div className="text-sm text-gray-700">
        Výběr: <b>{vek}</b> → <b>{prvek || "—"}</b>
      </div>

      {item ? (
        <section className="grid gap-4 md:grid-cols-2">
          <PrvekCard item={item} vek={vek} />
        </section>
      ) : (
        <div className="text-sm text-gray-600">
          Nic jsme nenašli pro zvolený ročník a hru.
        </div>
      )}
    </main>
  );
}
